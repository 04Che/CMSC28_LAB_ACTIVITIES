#include <iostream>
using namespace std;

// ACTIVITY 1.2
// Class Definition
class NailPolish {
// Nail Polish Attributes 
private:
    string brand;
    string color;
    float price;
// Nail Polish Constructor 
public:
    NailPolish(string y, string x, float z);
// Member function to display Nail Polish Details 
    void displayDetails();
};


